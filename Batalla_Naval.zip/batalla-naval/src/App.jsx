import { useState, useEffect, Fragment } from 'react'
import './App.css'

function App() {

  const [barcos1, setBarcos1] = useState([])
  const [barcos2, setBarcos2] = useState([])

  const [jugador, setJugador] = useState(1)
  const [barcoSeleccionado, setBarcoSeleccionado] = useState(4)
  const [orientacion, setOrientacion] = useState("horizontal")

  const [fase, setFase] = useState("organizacion")
  const [turno, setTurno] = useState(1)
  const [mostrarCambio, setMostrarCambio] = useState(false)

  const [disparos1, setDisparos1] = useState([])
  const [disparos2, setDisparos2] = useState([])

  const [mensaje1, setMensaje1] = useState("")
  const [mensaje2, setMensaje2] = useState("")
  const [ganador, setGanador] = useState(0)

  const [tiempo, setTiempo] = useState(30)
  const [reinicioTiempo, setReinicioTiempo] = useState(0)

  const tamaños = [4, 5, 3]

  let barcosActuales = jugador === 1 ? barcos1 : barcos2

  // Temporizador
  useEffect(() => {

    if (fase !== "batalla" || mostrarCambio) {
      return
    }

    setTiempo(30)

    let intervalo = setInterval(() => {
      setTiempo(t => t > 0 ? t - 1 : 0)
    }, 1000)

    return () => clearInterval(intervalo)

  }, [fase, turno, reinicioTiempo, mostrarCambio])

  // Cambio de turno por tiempo agotado
  useEffect(() => {

    if (tiempo === 0 && fase === "batalla" && !mostrarCambio) {

      if (turno === 1) {
        setMensaje1("¡Tiempo agotado! Perdiste tu turno.")
        setMensaje2("El jugador 1 perdió su turno.")
        setTurno(2)
        setMostrarCambio(true)
      } else {
        setMensaje2("¡Tiempo agotado! Perdiste tu turno.")
        setMensaje1("El jugador 2 perdió su turno.")
        setTurno(1)
        setMostrarCambio(true)
      }
    }

  }, [tiempo, fase, turno, mostrarCambio])

  // Colocar barcos
  function colocarBarco(fila, columna) {

    let posiciones = []

    if (orientacion === "horizontal") {
      for (let i = 0; i < barcoSeleccionado; i++) {
        posiciones.push(`${fila}-${columna + i}`)
      }
    } else {
      for (let i = 0; i < barcoSeleccionado; i++) {
        posiciones.push(`${fila + i}-${columna}`)
      }
    }

    // Comprobar que el barco no salga del tablero
    if (posiciones.some(pos => {
      let [f, c] = pos.split("-").map(Number)
      return f >= 6 || c >= 6
    })) {
      alert("El barco no cabe en esa posición")
      return
    }

    // Comprobar que no se superpongan los barcos
    if (barcosActuales.some(barco =>
      barco.posiciones.some(pos => posiciones.includes(pos))
    )) {
      alert("Esa posición ya está ocupada")
      return
    }

    let nuevosBarcos = [...barcosActuales, {
      tamaño: barcoSeleccionado,
      posiciones: posiciones
    }]

    if (jugador === 1) {
      setBarcos1(nuevosBarcos)
    } else {
      setBarcos2(nuevosBarcos)
    }

    // Pasar al siguiente jugador
    if (nuevosBarcos.length === 3) {

      if (jugador === 1) {
        setJugador(2)
        setBarcoSeleccionado(4)
        setFase("cambio")
      } else {
        setFase("batalla")
        setTurno(1)
        setMostrarCambio(true)
        setMensaje1("¡La batalla ha comenzado!")
        setMensaje2("¡La batalla ha comenzado!")
      }

    } else {

      let siguiente = tamaños.find(t =>
        !nuevosBarcos.some(barco => barco.tamaño === t)
      )

      setBarcoSeleccionado(siguiente)
    }
  }

  // Limpiar barcos del jugador actual
  function limpiarTablero() {

    if (jugador === 1) {
      setBarcos1([])
    } else {
      setBarcos2([])
    }

    setBarcoSeleccionado(4)
    setMensaje1("Tablero limpiado.")
    setMensaje2("Tablero limpiado.")
  }

  // Cambiar orientación
  function cambiarOrientacion() {

    if (orientacion === "horizontal") {
      setOrientacion("vertical")
    } else {
      setOrientacion("horizontal")
    }
  }

  // Realizar disparos
  function disparar(fila, columna) {

    let posicion = `${fila}-${columna}`

    let disparosActuales = turno === 1 ? disparos1 : disparos2
    let barcosEnemigos = turno === 1 ? barcos2 : barcos1

    // Evitar disparar dos veces
    if (disparosActuales.some(disparo => disparo.posicion === posicion)) {
      alert("Ya disparaste a esta casilla")
      return
    }

    setReinicioTiempo(reinicioTiempo + 1)

    // Comprobar si hay un barco
    let acierto = barcosEnemigos.some(barco =>
      barco.posiciones.includes(posicion)
    )

    let nuevosDisparos = [...disparosActuales, {
      posicion: posicion,
      acierto: acierto
    }]

    if (turno === 1) {
      setDisparos1(nuevosDisparos)
    } else {
      setDisparos2(nuevosDisparos)
    }

    if (acierto) {

      if (turno === 1) {
        setMensaje1("¡Has impactado!")
        setMensaje2("¡Fuiste impactado!")
      } else {
        setMensaje2("¡Has impactado!")
        setMensaje1("¡Fuiste impactado!")
      }

      // Comprobar si se hundió un barco completo
      let barcoHundido = barcosEnemigos.some(barco =>
        barco.posiciones.every(pos =>
          nuevosDisparos.some(disparo =>
            disparo.posicion === pos && disparo.acierto
          )
        )
      )

      if (barcoHundido) {
        setGanador(turno)
        setMensaje1("¡Un barco ha sido hundido!")
        setMensaje2("¡Un barco ha sido hundido!")
        setFase("final")
      }

    } else {

      if (turno === 1) {
        setMensaje1("¡Has fallado! Ahora juega el jugador 2.")
        setMensaje2("El jugador 1 ha fallado. Es tu turno.")
        setTurno(2)
        setMostrarCambio(true)
      } else {
        setMensaje2("¡Has fallado! Ahora juega el jugador 1.")
        setMensaje1("El jugador 2 ha fallado. Es tu turno.")
        setTurno(1)
        setMostrarCambio(true)
      }
    }
  }

  // Información de los tableros
  let barcosPropios = turno === 1 ? barcos1 : barcos2
  let disparosPropios = turno === 1 ? disparos2 : disparos1
  let disparosTablero = turno === 1 ? disparos1 : disparos2

  // Reiniciar toda la partida
  function nuevaPartida() {

    setBarcos1([])
    setBarcos2([])

    setDisparos1([])
    setDisparos2([])

    setJugador(1)
    setTurno(1)

    setMostrarCambio(false)

    setBarcoSeleccionado(4)
    setOrientacion("horizontal")

    setMensaje1("")
    setMensaje2("")
    setGanador(0)

    setTiempo(30)
    setReinicioTiempo(0)

    setFase("organizacion")
  }

  return (
    <div className="contenedor">

      <h1>⚓BATALLA NAVAL⚓</h1>

      <p className="subtitulo">Juego para dos jugadores</p>

      {/* ORGANIZACIÓN */}
      {fase === "organizacion" && (
        <>
          <h2>Organización del Jugador {jugador}</h2>
          <p>Coloca tus tres barcos en el tablero.</p>
          <h3>Selecciona tu barco</h3>

          {tamaños.map(tamaño => (
            <button
              key={tamaño}
              className={barcoSeleccionado === tamaño ? "seleccionado" : ""}
              disabled={barcosActuales.some(barco => barco.tamaño === tamaño)}
              onClick={() => setBarcoSeleccionado(tamaño)}
            >
              Barco de {tamaño} casillas
            </button>
          ))}

          <h3>Orientación</h3>

          <button onClick={cambiarOrientacion}>
            Orientación: {orientacion === "horizontal" ? "Horizontal ↔" : "Vertical ↕"}
          </button>

          <h3>Tablero del Jugador {jugador}</h3>

          <div className="tablero">

            <div></div>

            {['A', 'B', 'C', 'D', 'E', 'F'].map(letra => (
              <div className="coordenada" key={letra}>{letra}</div>
            ))}

            {[0, 1, 2, 3, 4, 5].map(fila => (
              <Fragment key={fila}>

                <div className="coordenada">{fila + 1}</div>

                {['A', 'B', 'C', 'D', 'E', 'F'].map((letra, columna) => {

                  let ocupado = barcosActuales.some(barco =>
                    barco.posiciones.includes(`${fila}-${columna}`)
                  )

                  return (
                    <div
                      key={letra}
                      className={ocupado ? "casilla ocupada" : "casilla"}
                      onClick={() => colocarBarco(fila, columna)}
                    ></div>
                  )
                })}

              </Fragment>
            ))}

          </div>

          <p>Barcos organizados: {barcosActuales.length} de 3</p>

          <button className="limpiar" onClick={limpiarTablero}>
            Limpiar tablero
          </button>
        </>
      )}

      {/* CAMBIO DE JUGADOR */}
      {fase === "cambio" && (
        <div className="pantalla-cambio">

          <h2>¡Jugador 1 ha terminado!</h2>
          <p>Entrega el dispositivo al Jugador 2.</p>
          <p>No observes la pantalla mientras el otro jugador organiza sus barcos.</p>

          <button onClick={() => setFase("organizacion")}>
            Estoy listo
          </button>

        </div>
      )}

      {/* BATALLA */}
      {fase === "batalla" && (
        <>
          {mostrarCambio ? (

            <div className="pantalla-cambio">

              <h2>¡Turno del Jugador {turno}!</h2>

              <p>Entrega el dispositivo al Jugador {turno}.</p>

              <p>No observes la pantalla mientras el otro jugador prepara su turno.</p>

              <button onClick={() => setMostrarCambio(false)}>
                Estoy listo
              </button>

            </div>

          ) : (

            <>
              <h2>Turno del Jugador {turno}</h2>

              <h3 className="temporizador">
                Tiempo restante: {tiempo} segundos
              </h3>

              <p className="mensaje">
                {turno === 1 ? mensaje1 : mensaje2}
              </p>

              <div className="tableros-batalla">

                {/* TABLERO PROPIO */}
                <div className="panel-tablero">

                  <h3>Mi tablero</h3>

                  <div className="tablero">

                    <div></div>

                    {['A', 'B', 'C', 'D', 'E', 'F'].map(letra => (
                      <div className="coordenada" key={letra}>{letra}</div>
                    ))}

                    {[0, 1, 2, 3, 4, 5].map(fila => (
                      <Fragment key={fila}>

                        <div className="coordenada">{fila + 1}</div>

                        {['A', 'B', 'C', 'D', 'E', 'F'].map((letra, columna) => {

                          let posicion = `${fila}-${columna}`

                          let disparo = disparosPropios.find(d =>
                            d.posicion === posicion
                          )

                          let ocupado = barcosPropios.some(barco =>
                            barco.posiciones.includes(posicion)
                          )

                          return (
                            <div
                              key={letra}
                              className={
                                disparo
                                  ? disparo.acierto ? "casilla impacto" : "casilla fallido"
                                  : ocupado ? "casilla ocupada" : "casilla"
                              }
                            >
                              {disparo ? disparo.acierto ? "●" : "X" : ""}
                            </div>
                          )
                        })}

                      </Fragment>
                    ))}

                  </div>

                  <p>Mis barcos: {barcosPropios.length}</p>

                </div>

                {/* TABLERO ENEMIGO */}
                <div className="panel-tablero">

                  <h3>Tablero enemigo</h3>

                  <div className="tablero">

                    <div></div>

                    {['A', 'B', 'C', 'D', 'E', 'F'].map(letra => (
                      <div className="coordenada" key={letra}>{letra}</div>
                    ))}

                    {[0, 1, 2, 3, 4, 5].map(fila => (
                      <Fragment key={fila}>

                        <div className="coordenada">{fila + 1}</div>

                        {['A', 'B', 'C', 'D', 'E', 'F'].map((letra, columna) => {

                          let posicion = `${fila}-${columna}`

                          let disparo = disparosTablero.find(d =>
                            d.posicion === posicion
                          )

                          return (
                            <div
                              key={letra}
                              className={
                                disparo
                                  ? disparo.acierto ? "casilla impacto" : "casilla fallido"
                                  : "casilla"
                              }
                              onClick={() => disparar(fila, columna)}
                            >
                              {disparo ? disparo.acierto ? "●" : "X" : ""}
                            </div>
                          )
                        })}

                      </Fragment>
                    ))}

                  </div>

                  <p>Disparos realizados: {disparosTablero.length}</p>

                </div>

              </div>

              <p className="instruccion">
                Haz clic en una casilla del tablero enemigo para disparar.
              </p>
            </>

          )}
        </>
      )}

      {/* FINAL */}
      {fase === "final" && (
        <div className="pantalla-final">

          <h2>¡Partida terminada!</h2>

          <h1>Jugador {ganador} ha ganado</h1>

          <h3>Jugador {ganador === 1 ? 2 : 1}, has perdido.</h3>

          <p>¡Gracias por jugar!</p>

          <button onClick={nuevaPartida}>
            Nueva partida
          </button>

        </div>
      )}

    </div>
  )
}

export default App